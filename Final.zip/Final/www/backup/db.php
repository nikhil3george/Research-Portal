<?php
/* database connection settings*/
$host = 'localhost';
$pass = 'mypass123';
$db = 'accounts';
$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);
