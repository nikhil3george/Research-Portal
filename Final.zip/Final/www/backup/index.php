<!doctype html>
<html>
 <head>

   <title>Research Portal</title> 
   <link rel="stylesheet" href="style.css">

</head>
 
 <body>
    <header>
          <div class="main">
                <div class="logo">
                    <img src="IITPatna_logo.png"> 
                 </div>
           <ul>
                  <li><a href="index.php">Home</a></li>
                 
                  <li><a href="https://www.iitp.ac.in/index.php/component/content/article/555-iitpatna-webmail.html">IITP Webmail</a></li>
                  <li><a href="https://www.iitp.ac.in/">About</a></li>
                  <li><a href="https://www.iitp.ac.in/index.php/contact.html">Contact</a></li>
            </ul>
           </div>
           <div class="title">
               <h1>Research Portal</h1>
           </div>
           <div class="button">

      <a href="login1.php" class="btn">LOGIN</a>
           <a href="signup1.php" class="btn">SIGN UP</a>

           </div>
      <header> 
</body>
</html>









 