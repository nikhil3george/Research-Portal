
<!doctype html>
<html>
 <head>

   <title>Login Form</title>
   <link rel="stylesheet" href="style.css">

</head>

 <body>
<div class="login-box">

<h1>Login</h1>

<div class="textbox">
<img class="icon" src="user.png"></img>
<input type="text" placeholder="Username" name="" value="">
</div>

<div class="textbox">
<img class="icon" src="lock1.png"></img>
<input type="password" placeholder="Password" value="" name="pw" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
</div>
<input class="btna" type="button" name="login" value="Sign in">

</div>



  </body> 
</html>







