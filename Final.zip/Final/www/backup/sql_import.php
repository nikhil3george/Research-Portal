<?php
//connection variables
$host = 'localhost';
$user = 'root';
$password = 'mypass123';

//create mysql connection
$mysqli = new mysqli($host,$user,$password);
if($mysqli->connect_errno) {
   printf("connection failed: %\n", $mysqli->connect_error);
   die();
}
//create the database
if( !$mysqli->query('create database accounts') ) {
   printf("errormessage: %s\n",$mysqli->error);
}

// create users table with all the fields
$mysqli->query('
 



 
create table 'accounts','users'
(
   'id' int not null auto_increment,
   'first_name' varchar(50) not null,
   'last_name' varchar(50) not null,
    'email' varchar(100) not null,
    'password' varchar(100) not null,
    'hash' varchar(32) not null,
    'active'bool not null default 0,
primary key ('id')
);') or die($mysqli->error);
?>




