<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
Header("Location: index.php");
die();
}
?>

<html>
<head><title>Dashboard</title></head>
<body>
<h2>Dashboard</h2>

<table>
<tr><th>ID</th><th>Title</th><th>Journal</th><th>Authors</th><th>Vol-pp</th><th>Date</th></tr>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "publications";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM journal_pubs INNER JOIN journals on journal_pubs.jid = journals.jid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
while($row = $result->fetch_assoc()) {
    echo "<tr><td>".$row["jentryid"]."</td><td>".$row["title"]."</td><td>".$row["name"]."</td><td>".$row["authors"]."</td><td>".$row["volpp"]."</td><td>".$row["date"]."</td></tr>";
}
}

?>
</table>
</body>
</html>