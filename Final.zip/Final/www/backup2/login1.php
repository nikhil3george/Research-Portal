<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "publications";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM php_ui_users WHERE user = '".$_POST["user"]."' AND pass = '".$_POST["pass"]."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  session_start();
  $_SESSION["loggedin"] = true;
  $_SESSION["user"] = $_POST["user"];
  Header("Location: dashboard.php");
  die();
} else {
  echo "Wrong password";
}
?>