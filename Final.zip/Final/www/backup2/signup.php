<html>
<head><title>Signup</title></head>
<body>
<h2>Signup</h2>
<form action="signup1.php" method="post">
<p><label>Username: </label><input type="text" name="user"></p>
<p><label>Password: </label><input type="password" name="pass"></p>
<p><input type="submit"></p>
</form>
</body>
</html>