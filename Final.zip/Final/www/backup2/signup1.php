<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "publications";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO php_ui_users values ('".$_POST["user"]."', '".$_POST["pass"]."')";
$result = $conn->query($sql);

if ($result) {
Header("Location: index.php");
die();
} else {
echo "Failed.";
}
?>