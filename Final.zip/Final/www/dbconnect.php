<?php
$servername = "localhost";
$username = "root";
$password = "test";

// Create connection
$conn = new mysqli("db", "root", "test", "publications");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>