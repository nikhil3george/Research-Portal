<?php

require "enforcelogout.php";

session_unset();
session_destroy();

session_start();

require "dbconnect.php";

if (!isset($_POST["user"]) || !isset($_POST["pass"])) {
    $_SESSION["indexmsg"] = "Login to access the page";
    $_SESSION["indexmsgerr"] = true;
    Header("Location: index.php");
    die();
}

$user = $_POST["user"];
$pass = md5($_POST["pass"]);

$sql = $conn->prepare("INSERT INTO php_ui_users VALUES (?,?)");
$sql->bind_param('ss',$user,$pass);
$sql->execute();

Header("Location: index.php");
die();

?>